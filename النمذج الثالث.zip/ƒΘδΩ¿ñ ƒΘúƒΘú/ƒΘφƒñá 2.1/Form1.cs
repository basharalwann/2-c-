﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace الواجب_2._1
{
    
    public partial class Form1 : Form
    {
        double n1;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الذي ادخلته غير صحيح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                
                textBox1.Text = "";
                textBox1. Focus();
                   return;
            }
            double sum=0 ;
            for (int i = 0; i <= n1; i++)
            {
                sum += i;
            }
            label1.Text = sum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);

            }
            catch (Exception)
            {
                MessageBox.Show("العدد الذي ادخلته غير صحيح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            double fac =1;
            for (int i = 1; i <= n1; i++)
            {
                fac *= i;
            }
            label2.Text = fac.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);

            }
            catch (Exception)
            {
                MessageBox.Show("العدد المدخل غير صحيح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            double sq = Math.Sqrt(n1);
            label3.Text = sq.ToString();
        }
    }
}
