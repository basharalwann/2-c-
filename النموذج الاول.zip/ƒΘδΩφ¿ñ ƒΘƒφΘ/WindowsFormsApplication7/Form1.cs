﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            double number1, number2, number3;
            string operation1 = textBox2.Text; 
            // العملية الأولى
            string operation2 = textBox4.Text;
            // العملية الثانية
            string intermdiaResult = " ";
            string finalResult = " ";

            if (double.TryParse(textBox1.Text, out number1) &&
                double.TryParse(textBox3.Text, out number2) &&
                double.TryParse(textBox5.Text, out number3))
            {
                // إذا كانت العملية الثانية ضرب أو قسمة
                if (operation2 == "*" || operation2 == "/")
                {
                    intermdiaResult = PerformOperation(number2, number3, operation2).ToString();
                    if (intermdiaResult == "NaN")
                    {
                        MessageBox.Show("العملية الثانية غير صالحه");
                        textBox5.Focus();
                        return;
                    }
                    finalResult = PerformOperation(number1, Convert.ToDouble(intermdiaResult), operation1).ToString();
                }
                else
                {
                    intermdiaResult = PerformOperation(number1, number2, operation1).ToString();
                    if (intermdiaResult == "NaN")
                    {
                        MessageBox.Show("العملية الأولى غير صالحه");
                        textBox2.Focus();
                        return;
                    }
                    finalResult = PerformOperation(Convert.ToDouble(intermdiaResult), number3, operation2).ToString();
                }

                textBox6.Text = finalResult.ToString();
            }
            else
            {
                MessageBox.Show("يرجئ التأكد من عدم ترك حقل فارغ");
            }
        }

        private double PerformOperation(double num1, double num2, string operation)
        {
            switch (operation)
            {
                case "+":
                    return num1 + num2;
                case "-":
                    return num1 - num2;
                case "*":
                    return num1 * num2;
                case "/":
                    return num2 != 0 ? num1 / num2 : double.NaN;
                default:
                    return double.NaN; // عملية غير فعاله
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

