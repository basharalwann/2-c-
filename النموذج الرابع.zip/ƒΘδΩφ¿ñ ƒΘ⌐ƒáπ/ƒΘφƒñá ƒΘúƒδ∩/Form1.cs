﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace الواجب_الثاني
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void train(object sender, EventArgs e)
        {
            if (sender is Button)
            {
                MessageBox.Show("تم الضغط على أداة button");
            }
            else if (sender is Label)
            {
                MessageBox.Show("تم الضغط على أداة label");
            }

            if (sender == buttonyellow)
                button4.BackColor = Color.Yellow;
            else if (sender == buttonred)
                button4.BackColor = Color.Red;
            else if (sender == buttongreen)
                button4.BackColor = Color.Green;
            else if (sender == label2)
                button4.Text = label2.Text;
            else if (sender == label1)
                button4.Text = label1.Text;
        }
    }
}
