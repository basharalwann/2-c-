﻿namespace الواجب_الثاني
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonyellow = new System.Windows.Forms.Button();
            this.buttonred = new System.Windows.Forms.Button();
            this.buttongreen = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonyellow
            // 
            this.buttonyellow.Location = new System.Drawing.Point(227, 152);
            this.buttonyellow.Name = "buttonyellow";
            this.buttonyellow.Size = new System.Drawing.Size(75, 29);
            this.buttonyellow.TabIndex = 0;
            this.buttonyellow.Text = "اصفر";
            this.buttonyellow.UseVisualStyleBackColor = true;
            this.buttonyellow.Click += new System.EventHandler(this.train);
            // 
            // buttonred
            // 
            this.buttonred.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.buttonred.Location = new System.Drawing.Point(227, 12);
            this.buttonred.Name = "buttonred";
            this.buttonred.Size = new System.Drawing.Size(75, 34);
            this.buttonred.TabIndex = 1;
            this.buttonred.Text = "احمر";
            this.buttonred.UseVisualStyleBackColor = true;
            this.buttonred.Click += new System.EventHandler(this.train);
            // 
            // buttongreen
            // 
            this.buttongreen.Location = new System.Drawing.Point(227, 84);
            this.buttongreen.Name = "buttongreen";
            this.buttongreen.Size = new System.Drawing.Size(75, 31);
            this.buttongreen.TabIndex = 2;
            this.buttongreen.Text = "اخضر";
            this.buttongreen.UseVisualStyleBackColor = true;
            this.buttongreen.Click += new System.EventHandler(this.train);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 93);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 31);
            this.button4.TabIndex = 3;
            this.button4.Text = "button1";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.train);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(199, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "جهاز1";
            this.label1.Click += new System.EventHandler(this.train);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 230);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "جهاز2";
            this.label2.Click += new System.EventHandler(this.train);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 305);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.buttongreen);
            this.Controls.Add(this.buttonred);
            this.Controls.Add(this.buttonyellow);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonyellow;
        private System.Windows.Forms.Button buttonred;
        private System.Windows.Forms.Button buttongreen;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

